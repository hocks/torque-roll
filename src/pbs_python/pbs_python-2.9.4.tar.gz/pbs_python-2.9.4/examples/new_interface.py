#!/usr/bin/env python
#
# Author: Bas van der Vlies <basv@sara.nl>
# Date  : 02 March 2005
# Desc. : Usage of the new PBSQuery module
#
# SVN info:
# $Id: new_interface.py 74 2005-03-04 09:11:10Z bas $
#
#
#

from PBSQuery import PBSQuery

def main():

  p = PBSQuery()

  nodes = p.getnodes()
  for name, node in nodes.items():
  	print node
	if node.is_free():
		print "%s : Found an free node" %name

  jobs = p.getjobs()
  for name, job in jobs.items():
     for key in job.keys():
        print '%s = %s' %(key, job[key])
 
  l = ['state', 'np' ]
  nodes = p.getnodes(l)
  for node in nodes.values():
     print node

main()
