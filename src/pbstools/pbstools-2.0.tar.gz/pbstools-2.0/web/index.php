<?php
# Copyright 2006 Ohio Supercomputer Center
# Revision info:
# $HeadURL: http://svn.osc.edu/repos/pbstools/releases/pbstools-2.0/web/index.php $
# $Revision: 93 $
# $Date: 2006-02-15 13:53:25 -0500 (Wed, 15 Feb 2006) $
require_once 'page-layout.php';

page_header("");
page_footer();
?>