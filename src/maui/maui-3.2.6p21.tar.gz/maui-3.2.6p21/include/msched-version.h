#define MSCHED_VERSION "3.2.6p21"
#define MSCHED_SVERSION "maui-3.2.6p21"
