/*
Package:  maui
Module:   mclient-stub.c
Version:  3.2.6p18

Copyright:

  Copyright (C) 1999-2006 Cluster Resources, Inc

  All Rights Reserved

Disclaimer:

  

*/

#if defined(__MLL) || defined(__MLL2) || defined(__MLL31)

int MLLLoadModule(mrmfunc_t *F) { return(SUCCESS); }

#endif /* __MLL || __MLL2 || __MLL31 */

/* END mclient-stub.c */

